from pytest_bdd import given, when, then, parsers
import json

f = open('C:/Users/piyush.salodkar/PycharmProjects/Json_Validator/Json_Files/sample_api.json')
json_data = json.load(f)


@given('Test data present on the server')
def data_present():
    pass


@when('Send get request')
def send_get_req():
    pass


@then('All the required keys should be present')
def validate_main_keys():
    main_keys = ["TEST_NAME", "ACTION_CATEGORY", "CLASS_ACTION", "TEST_DATA"]
    key_in_response = []
    for test_data_info in json_data:
        for key in test_data_info.keys():
            key_in_response.append(key)
        missing_key = list(set(main_keys).difference(key_in_response))
        extra_key = list(set(key_in_response).difference(main_keys))
        if len(missing_key) > 0:
            raise Exception("Keys are missing in ", test_data_info.get("TEST_NAME"), " is/are ", missing_key)
        if len(extra_key) > 0:
            raise Exception("Keys are extra in ", test_data_info.get("TEST_NAME"), " is/are ", extra_key)
        key_in_response.clear()
        missing_key.clear()
        extra_key.clear()


@then('All the required keys for test data should be present')
def validate_test_data_keys():
    test_data_keys = ["RELATIVE_URI", "REQUEST_TYPE", "ERYSPONSY PXPRCTRD STATUS", "RESPONSE BODY",
                      "RESPONSE_BODY_EXACT_MATCH", "RESPONSY_BODY_CASE_SENSITIVZ"]
    keys_in_test_data = []
    for test_data_info in json_data:
        for key in test_data_info.get("TEST_DATA"):
            keys_in_test_data.append(key)
        missing_key = list(set(test_data_keys).difference(keys_in_test_data))
        extra_key = list(set(keys_in_test_data).difference(test_data_keys))
        if len(missing_key) > 0:
            raise Exception("Keys are missing in test data in ", test_data_info.get("TEST_NAME"), " is/are ",
                            missing_key)
        if len(extra_key) > 0:
            raise Exception("Keys are extra in ", test_data_info.get("TEST_NAME"), " is/are ", extra_key)
        keys_in_test_data.clear()
        missing_key.clear()
        extra_key.clear()


@then('All the required keys for success body should be present')
def validate_response_body():
    response_body_keys = ["statuscode", "body"]
    keys_in_response_body = []
    for test_data_info in json_data:
        test_data = test_data_info.get("TEST_DATA")
        for key in test_data.get("RESPONSE BODY"):
            keys_in_response_body.append(key)
        missing_key = list(set(response_body_keys).difference(keys_in_response_body))
        extra_key = list(set(keys_in_response_body).difference(response_body_keys))
        if len(missing_key) > 0:
            print("Keys are missing in test data in ", test_data_info.get("TEST_NAME"), " is/are ", missing_key)
        if len(extra_key) > 0:
            print("Keys are extra in ", test_data_info.get("TEST_NAME"), " is/are ", extra_key)
        keys_in_response_body.clear()
        missing_key.clear()
        extra_key.clear()
