import pytest
from pytest_bdd import scenario
from Step_Defination.response_json_validator.steps import *


@scenario("../../Feature_files/response_json_validator.feature", "Json Key Validate")
def test_json_validator():
    pass


@scenario("../../Feature_files/response_json_validator.feature", "Test Data Key Validate")
def test_data_keys_validator():
    pass


@scenario("../../Feature_files/response_json_validator.feature", "Success Body Key Validate")
def test_success_body_data_keys_validator():
    pass
